class unipolar:
    def manchester(data) -> None:
        """Manchester coding
        The data is preceded by one low (0) bit and succeded by one low (0) bit
        for the sake of synchronization
        Data must be therefore of 18 characters long in total."""
        if data[0] != "0" or data[-1] != "0" or len(data) != 18:
            print("<!>", end="", flush=True) # Invalid Byte
            return
        byte = ""
        try:
            for i in range(1, len(data) - 2, 2):
                pair = data[i:i+2]
                if pair == "10":
                    byte += "0"
                elif pair == "01":
                    byte += "1"
                else:
                    print("<!>", end="", flush=True)
                    return
        except Exception as e:
            print(e)
            return
        print(chr(int(byte, 2)), end="", flush=True)
        
    
    def NRZ(data) -> None:
        "Non Return to Zero coding"
        print("NRZ:", data) # Placeholder