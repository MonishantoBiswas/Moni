# Cetrion 2023
# This program should be able to decode arbitrary number of similar bit sequence.
# for that thickness of the strips must be very large compared to shutter loss
# Todo: Check for possible memory overflow for queue operation
import cv2
from queue import Queue
from time import sleep
import numpy as np
import warnings

class receiver:
    def __init__(self, callback) -> None:
        self.callback = callback
        self.stream = ""
        self.q = Queue()
        self.flag = False
        self.data = None # Frame containing information
        self.width = 30
        self.shutter_loss = 7 # Pixel loss due to frame transitioning
    

    def isStriped(self, gray_image, brightness_threshold = 170) -> bool:
        "Check if a frame is striped"
        # Apply Canny edge detection
        edges = cv2.Canny(gray_image, threshold1=100, threshold2=200) # Calibrate here
        # For instance, you can calculate the average pixel intensity of bright and dark areas
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            average_bright = gray_image[edges > 0].mean()

        ## Condition to declare: May be changed
        if np.isnan(average_bright):
                return False
        if average_bright < brightness_threshold:
            return True
        return False
    

    def transfer(self, h, type) -> None:
        "Converts height to number of bits"
        # Reduce the effective shutter loss value
        no = round((h + self.shutter_loss) / self.width)
        #print(type * no, end="")
        self.stream += type*no
        

    def convert(self) -> None:
        "Retrieves Binary data from B&W image"
        # Apply binary threshold to segment black strips
        _, binary_image = cv2.threshold(self.data, 80, 200, cv2.THRESH_BINARY_INV) # Calibrate here
        # Find contours in the binary image
        contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        init = None
        for contour in reversed(contours):
            x, y, w, h = cv2.boundingRect(contour)
            if init:
                self.transfer(y - init, "1")
            self.transfer(h, "0")
            init = y + h
        #print("")
            
    
    def parallel(self) -> None:
        "Executes processing operations in parallel"
        while True:
            try:
                frame = self.q.get(block=False)
            except:
                if self.flag:
                    return
                else:
                    sleep(0.05) # Adjust
                    continue
            frame = cv2.resize(frame, (640, 480)) # Resize
            frame = frame[:, 220:420] # ROI Cropping
            # Convert the image to grayscale
            gray_image = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            if self.isStriped(gray_image):
                if self.data is None:
                    self.data = gray_image
                else:
                    self.data = cv2.vconcat([self.data, gray_image])
            else:
                if self.data is not None:
                    #print(self.q.qsize())
                    self.convert()
                    #print(self.q.qsize())
                    self.data = None
                    self.callback(self.stream)
                    self.stream = ""
       
